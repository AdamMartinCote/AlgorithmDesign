# INF8775 TP1

## dépendences

l'execution du programme nécessite les librairie "numpy" et "matplotlib".

## scripte tp.sh

Le scripte `tp.sh` est un proxy qui redirige vers tp1.py, en python
