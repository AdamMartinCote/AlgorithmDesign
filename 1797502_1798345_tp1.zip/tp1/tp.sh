##
## This is a wraper on the python script
##
python3 ./tp1.py "$@"
