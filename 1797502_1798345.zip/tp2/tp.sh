##
## This is a wraper on the python script
##
./tp2.py "$@"
